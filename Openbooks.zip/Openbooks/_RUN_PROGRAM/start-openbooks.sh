#!/bin/bash
echo "========================================"
echo "        Starting OpenBooks"
echo "========================================"
echo ""

echo "Starting Firebase Admin Server..."
node firebase-admin-server.js &
NODE_PID=$!

sleep 2

echo "Starting Web Server..."
python3 server.py &
PYTHON_PID=$!

sleep 2

echo ""
echo "Opening OpenBooks in your browser..."

# Open browser based on OS
if [[ "$OSTYPE" == "darwin"* ]]; then
    open http://localhost:5000
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    xdg-open http://localhost:5000 2>/dev/null || echo "Please open http://localhost:5000 in your browser"
fi

echo ""
echo "========================================"
echo "OpenBooks is running!"
echo ""
echo "Press Ctrl+C to stop all servers..."
echo "========================================"

# Wait and cleanup on exit
trap "kill $NODE_PID $PYTHON_PID 2>/dev/null; echo 'Servers stopped. Goodbye!'; exit" INT TERM
wait
