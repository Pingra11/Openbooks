const express = require('express');
const cors = require('cors');
const admin = require('firebase-admin');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3001; // Different port from main Python server

// Enable CORS for all routes - handle preflight requests
app.use(cors({
  origin: true,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  preflightContinue: false,
  optionsSuccessStatus: 204
}));

app.use(express.json());

// Initialize Firebase Admin SDK
try {
  const serviceAccount = require('./firebase-service-account.json');
  
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    projectId: serviceAccount.project_id
  });
  
  console.log('Firebase Admin SDK initialized successfully');
} catch (error) {
  console.error('Error initializing Firebase Admin SDK:', error);
  process.exit(1);
}

// Create user endpoint
app.post('/create-firebase-user', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ 
        success: false, 
        error: 'Email and password are required' 
      });
    }

    // Create user with Firebase Admin SDK (doesn't affect current session)
    const userRecord = await admin.auth().createUser({
      email: email,
      password: password,
      emailVerified: false
    });
    
    console.log(`Successfully created Firebase Auth user: ${email} (${userRecord.uid})`);
    
    res.json({ 
      success: true, 
      message: `Firebase Auth user ${email} created successfully`,
      uid: userRecord.uid
    });
    
  } catch (error) {
    console.error('Error creating Firebase user:', error);
    
    res.status(500).json({ 
      success: false, 
      error: error.message,
      code: error.code || 'unknown-error'
    });
  }
});

// Update user endpoint
app.post('/update-firebase-user', async (req, res) => {
  try {
    const { currentEmail, newEmail, firstName, lastName, disabled } = req.body;
    
    if (!currentEmail) {
      return res.status(400).json({ 
        success: false, 
        error: 'Current email is required' 
      });
    }

    // Get user by current email first
    const userRecord = await admin.auth().getUserByEmail(currentEmail);
    
    // Prepare update data
    const updateData = {};
    
    if (newEmail && newEmail !== currentEmail) {
      updateData.email = newEmail;
    }
    
    if (firstName || lastName) {
      updateData.displayName = `${firstName || ''} ${lastName || ''}`.trim();
    }
    
    if (typeof disabled === 'boolean') {
      updateData.disabled = disabled;
    }
    
    // Update the user
    const updatedUser = await admin.auth().updateUser(userRecord.uid, updateData);
    
    console.log(`Successfully updated Firebase Auth user: ${currentEmail} -> ${newEmail || currentEmail} (${userRecord.uid})`);
    
    res.json({ 
      success: true, 
      message: `Firebase Auth user updated successfully`,
      uid: updatedUser.uid,
      updatedFields: Object.keys(updateData)
    });
    
  } catch (error) {
    console.error('Error updating Firebase user:', error);
    
    // Handle specific Firebase errors
    if (error.code === 'auth/user-not-found') {
      return res.status(404).json({ 
        success: false, 
        error: 'User not found in Firebase Auth',
        code: 'auth/user-not-found'
      });
    }
    
    if (error.code === 'auth/email-already-exists') {
      return res.status(400).json({ 
        success: false, 
        error: 'The new email address is already in use by another account',
        code: 'auth/email-already-exists'
      });
    }
    
    res.status(500).json({ 
      success: false, 
      error: error.message,
      code: error.code || 'unknown-error'
    });
  }
});

// Delete user by email endpoint
app.post('/delete-firebase-user', async (req, res) => {
  try {
    const { email } = req.body;
    
    if (!email) {
      return res.status(400).json({ 
        success: false, 
        error: 'Email is required' 
      });
    }

    // Get user by email first
    const userRecord = await admin.auth().getUserByEmail(email);
    
    // Delete the user using their UID
    await admin.auth().deleteUser(userRecord.uid);
    
    console.log(`Successfully deleted Firebase Auth user: ${email} (${userRecord.uid})`);
    
    res.json({ 
      success: true, 
      message: `Firebase Auth user ${email} deleted successfully`,
      uid: userRecord.uid
    });
    
  } catch (error) {
    console.error('Error deleting Firebase user:', error);
    
    // Handle specific Firebase errors
    if (error.code === 'auth/user-not-found') {
      return res.json({ 
        success: true, 
        message: 'User not found in Firebase Auth (may have been already deleted)',
        warning: 'User was not in Firebase Auth'
      });
    }
    
    res.status(500).json({ 
      success: false, 
      error: error.message,
      code: error.code || 'unknown-error'
    });
  }
});

// Send email endpoint using Replit Mail integration
app.post('/send-email', async (req, res) => {
  try {
    // Verify Firebase authentication token
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ 
        success: false, 
        error: 'Unauthorized: Missing authentication token' 
      });
    }

    const idToken = authHeader.split('Bearer ')[1];
    let decodedToken;
    
    try {
      decodedToken = await admin.auth().verifyIdToken(idToken);
    } catch (error) {
      console.error('Token verification failed:', error);
      return res.status(401).json({ 
        success: false, 
        error: 'Unauthorized: Invalid authentication token' 
      });
    }

    // Verify user role is administrator, manager, or accountant
    const userDoc = await admin.firestore().collection('users').doc(decodedToken.uid).get();
    if (!userDoc.exists) {
      return res.status(403).json({ 
        success: false, 
        error: 'Forbidden: User not found' 
      });
    }

    const userData = userDoc.data();
    const userRole = (userData.role || '').toLowerCase();
    const allowedRoles = ['administrator', 'manager', 'accountant'];
    if (!allowedRoles.includes(userRole)) {
      console.log(`User ${decodedToken.uid} with role ${userData.role} attempted to send email`);
      return res.status(403).json({ 
        success: false, 
        error: 'Forbidden: Only administrators, managers, and accountants can send emails' 
      });
    }

    const { to, cc, subject, text, html } = req.body;
    
    // Validate required fields
    if (!to || !subject || (!text && !html)) {
      return res.status(400).json({ 
        success: false, 
        error: 'Missing required fields: to, subject, and (text or html) are required' 
      });
    }

    // Validate email format (simple validation)
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const recipients = Array.isArray(to) ? to : [to];
    
    for (const email of recipients) {
      if (!emailRegex.test(email)) {
        return res.status(400).json({ 
          success: false, 
          error: `Invalid email address: ${email}` 
        });
      }
    }

    // Test domains that should be simulated instead of actually sending
    const testDomains = ['example.com', 'test.com', 'localhost', 'example.org'];
    
    // Check if all recipients are test domains
    const allTestDomains = recipients.every(email => {
      const domain = email.split('@')[1];
      return testDomains.includes(domain);
    });

    // If all recipients are test domains, simulate email sending for testing
    if (allTestDomains) {
      const mockMessageId = `test-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      
      console.log('📧 [TEST MODE] Simulating email send:');
      console.log(`  To: ${JSON.stringify(recipients)}`);
      console.log(`  Subject: ${subject}`);
      console.log(`  Message: ${text}`);
      console.log(`  Mock Message ID: ${mockMessageId}`);
      
      // Return a simulated success response
      return res.json({ 
        success: true, 
        message: 'Email sent successfully (test mode)',
        accepted: recipients,
        rejected: [],
        messageId: mockMessageId,
        testMode: true
      });
    }

    // For real email addresses, proceed with actual Replit Mail API
    // Get authentication token for Replit Mail service
    const xReplitToken = process.env.REPL_IDENTITY
      ? "repl " + process.env.REPL_IDENTITY
      : process.env.WEB_REPL_RENEWAL
        ? "depl " + process.env.WEB_REPL_RENEWAL
        : null;

    if (!xReplitToken) {
      console.error('No authentication token found for Replit Mail');
      return res.status(500).json({ 
        success: false, 
        error: 'Email service is not properly configured' 
      });
    }

    // Send email using Replit Mail API
    const response = await fetch(
      'https://connectors.replit.com/api/v2/mailer/send',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X_REPLIT_TOKEN': xReplitToken,
        },
        body: JSON.stringify({
          to: to,
          cc: cc,
          subject: subject,
          text: text,
          html: html
        }),
      }
    );

    if (!response.ok) {
      const error = await response.json();
      console.error('Replit Mail API error:', error);
      throw new Error(error.message || 'Failed to send email');
    }

    const result = await response.json();
    console.log(`📧 [PRODUCTION] Email sent successfully to ${to}. Message ID: ${result.messageId}`);
    
    res.json({ 
      success: true, 
      message: 'Email sent successfully',
      accepted: result.accepted,
      rejected: result.rejected,
      messageId: result.messageId,
      testMode: false
    });
    
  } catch (error) {
    console.error('Error sending email:', error);
    
    res.status(500).json({ 
      success: false, 
      error: error.message || 'Failed to send email'
    });
  }
});

// Send manager notification for journal entry submission
app.post('/notify-managers-journal-submission', async (req, res) => {
  try {
    // Verify Firebase authentication token
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ 
        success: false, 
        error: 'Unauthorized: Missing authentication token' 
      });
    }

    const idToken = authHeader.split('Bearer ')[1];
    let decodedToken;
    
    try {
      decodedToken = await admin.auth().verifyIdToken(idToken);
    } catch (error) {
      console.error('Token verification failed:', error);
      return res.status(401).json({ 
        success: false, 
        error: 'Unauthorized: Invalid authentication token' 
      });
    }

    // Verify user role is accountant or manager (who can submit entries)
    const userDoc = await admin.firestore().collection('users').doc(decodedToken.uid).get();
    if (!userDoc.exists) {
      return res.status(403).json({ 
        success: false, 
        error: 'Forbidden: User not found' 
      });
    }

    const userData = userDoc.data();
    const userRole = (userData.role || '').toLowerCase();
    if (userRole !== 'accountant' && userRole !== 'manager' && userRole !== 'administrator') {
      console.log(`Unauthorized user ${decodedToken.uid} (role: ${userData.role}) attempted to trigger manager notification`);
      return res.status(403).json({ 
        success: false, 
        error: 'Forbidden: Only accountants, managers, and administrators can submit journal entries for approval' 
      });
    }

    const { journalEntryNumber, submittedBy, date, description, totalAmount } = req.body;
    
    // Validate required fields
    if (!journalEntryNumber || !submittedBy) {
      return res.status(400).json({ 
        success: false, 
        error: 'Missing required fields: journalEntryNumber and submittedBy are required' 
      });
    }

    // Get all active users from Firestore (can't do case-insensitive role query directly)
    const usersSnapshot = await admin.firestore()
      .collection('users')
      .where('active', '==', true)
      .get();
    
    if (usersSnapshot.empty) {
      console.log('No active users found');
      return res.json({ 
        success: true, 
        message: 'No active users found',
        notified: 0
      });
    }

    // Filter for managers and collect their emails (case-insensitive)
    const managerEmails = [];
    usersSnapshot.forEach(doc => {
      const user = doc.data();
      const userRoleNormalized = (user.role || '').toLowerCase();
      if (userRoleNormalized === 'manager' && user.email && !user.suspended) {
        managerEmails.push(user.email);
      }
    });

    if (managerEmails.length === 0) {
      console.log('No manager emails found');
      return res.json({ 
        success: true, 
        message: 'No manager emails found',
        notified: 0
      });
    }

    // Prepare email content
    const subject = `🔔 New Journal Entry Awaiting Approval: ${journalEntryNumber}`;
    const text = `Hello,\n\nA new journal entry has been submitted for your approval:\n\n` +
      `Entry Number: ${journalEntryNumber}\n` +
      `Submitted By: ${submittedBy}\n` +
      `Date: ${date || 'N/A'}\n` +
      `Description: ${description || 'N/A'}\n` +
      `Total Amount: ${totalAmount || 'N/A'}\n\n` +
      `Please log in to OpenBooks to review and approve this journal entry.\n\n` +
      `Best regards,\nOpenBooks System`;

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2c3e50;">🔔 New Journal Entry Awaiting Approval</h2>
        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 10px 0;"><strong>Entry Number:</strong> ${journalEntryNumber}</p>
          <p style="margin: 10px 0;"><strong>Submitted By:</strong> ${submittedBy}</p>
          <p style="margin: 10px 0;"><strong>Date:</strong> ${date || 'N/A'}</p>
          <p style="margin: 10px 0;"><strong>Description:</strong> ${description || 'N/A'}</p>
          <p style="margin: 10px 0;"><strong>Total Amount:</strong> ${totalAmount || 'N/A'}</p>
        </div>
        <p>Please log in to <strong>OpenBooks</strong> to review and approve this journal entry.</p>
        <p style="color: #7f8c8d; font-size: 12px; margin-top: 30px;">
          This is an automated notification from OpenBooks. Please do not reply to this email.
        </p>
      </div>
    `;

    // Check if all emails are test domains
    const testDomains = ['example.com', 'test.com', 'localhost', 'example.org'];
    const allTestDomains = managerEmails.every(email => {
      const domain = email.split('@')[1];
      return testDomains.includes(domain);
    });

    // If test domains, simulate
    if (allTestDomains) {
      const mockMessageId = `notify-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      
      console.log('📧 [TEST MODE] Simulating manager notification:');
      console.log(`  To: ${JSON.stringify(managerEmails)}`);
      console.log(`  Subject: ${subject}`);
      console.log(`  Entry: ${journalEntryNumber}`);
      console.log(`  Mock Message ID: ${mockMessageId}`);
      
      return res.json({ 
        success: true, 
        message: 'Manager notification sent successfully (test mode)',
        notified: managerEmails.length,
        recipients: managerEmails,
        messageId: mockMessageId,
        testMode: true
      });
    }

    // Get authentication token for Replit Mail service
    const xReplitToken = process.env.REPL_IDENTITY
      ? "repl " + process.env.REPL_IDENTITY
      : process.env.WEB_REPL_RENEWAL
        ? "depl " + process.env.WEB_REPL_RENEWAL
        : null;

    if (!xReplitToken) {
      console.error('No authentication token found for Replit Mail');
      return res.status(500).json({ 
        success: false, 
        error: 'Email service is not properly configured' 
      });
    }

    // Send email using Replit Mail API
    const response = await fetch(
      'https://connectors.replit.com/api/v2/mailer/send',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X_REPLIT_TOKEN': xReplitToken,
        },
        body: JSON.stringify({
          to: managerEmails,
          subject: subject,
          text: text,
          html: html
        }),
      }
    );

    if (!response.ok) {
      const error = await response.json();
      console.error('Replit Mail API error:', error);
      throw new Error(error.message || 'Failed to send notification');
    }

    const result = await response.json();
    console.log(`📧 [PRODUCTION] Manager notification sent to ${managerEmails.length} manager(s). Message ID: ${result.messageId}`);
    
    res.json({ 
      success: true, 
      message: 'Manager notification sent successfully',
      notified: managerEmails.length,
      recipients: managerEmails,
      accepted: result.accepted,
      rejected: result.rejected,
      messageId: result.messageId,
      testMode: false
    });
    
  } catch (error) {
    console.error('Error sending manager notification:', error);
    
    res.status(500).json({ 
      success: false, 
      error: error.message || 'Failed to send notification'
    });
  }
});

// Clean up test data and seed realistic sample entries
app.post('/cleanup-and-seed', async (req, res) => {
  try {
    const db = admin.firestore();
    const batch = db.batch();
    
    // Step 1: Find and delete journal entries with "test" in description
    const journalEntriesSnapshot = await db.collection('journalEntries').get();
    const testEntryIds = [];
    const testEntryNumbers = [];
    
    journalEntriesSnapshot.forEach(doc => {
      const data = doc.data();
      const description = (data.description || '').toLowerCase();
      if (description.includes('test')) {
        testEntryIds.push(doc.id);
        testEntryNumbers.push(data.entryNumber);
        batch.delete(doc.ref);
      }
    });
    
    // Step 2: Delete corresponding event logs
    const eventLogsSnapshot = await db.collection('eventLogs').get();
    eventLogsSnapshot.forEach(doc => {
      const data = doc.data();
      // Delete event logs for journal entries
      if (data.eventType && data.eventType.includes('journal_entry')) {
        const accountName = data.accountName || '';
        // Check if this event log is for a test journal entry
        if (accountName.includes('Journal Entry') && testEntryNumbers.some(num => accountName.includes(`#${num}`))) {
          batch.delete(doc.ref);
        }
      }
    });
    
    // Commit deletions
    await batch.commit();
    console.log(`Deleted ${testEntryIds.length} test journal entries and their event logs`);
    
    // Step 3: Create realistic sample entries
    // Get accounts for realistic entries
    const accountsSnapshot = await db.collection('accounts').get();
    const accounts = {};
    accountsSnapshot.forEach(doc => {
      const data = doc.data();
      accounts[data.accountNumber] = { id: doc.id, name: data.accountName, number: data.accountNumber };
    });
    
    // Get next entry number
    const entriesSnapshot = await db.collection('journalEntries').orderBy('entryNumber', 'desc').limit(1).get();
    let nextEntryNumber = 1;
    if (!entriesSnapshot.empty) {
      nextEntryNumber = entriesSnapshot.docs[0].data().entryNumber + 1;
    }
    
    // Sample entries to create
    const sampleEntries = [
      {
        description: 'Office supplies purchased from ABC Supplies',
        date: new Date(2025, 9, 15), // Oct 15, 2025
        lineItems: [
          { account: '5000', debit: 250.00, credit: 0, description: 'Paper, pens, folders' },
          { account: '1000', debit: 0, credit: 250.00, description: 'Payment by check #1234' }
        ]
      },
      {
        description: 'Monthly rent payment for November 2025',
        date: new Date(2025, 10, 1), // Nov 1, 2025
        lineItems: [
          { account: '5000', debit: 1500.00, credit: 0, description: 'Office rent - November' },
          { account: '1000', debit: 0, credit: 1500.00, description: 'Rent payment' }
        ]
      },
      {
        description: 'Client payment received - Invoice #2501',
        date: new Date(2025, 9, 20), // Oct 20, 2025
        lineItems: [
          { account: '1000', debit: 3500.00, credit: 0, description: 'Payment received' },
          { account: '4000', debit: 0, credit: 3500.00, description: 'Consulting services rendered' }
        ]
      }
    ];
    
    const createdEntries = [];
    
    for (const sample of sampleEntries) {
      const entryNumber = nextEntryNumber++;
      const reference = `JE-${String(entryNumber).padStart(6, '0')}`;
      
      // Build line items with account data
      const lineItems = sample.lineItems.map(item => {
        const account = accounts[item.account];
        return {
          accountId: account?.id || '',
          accountNumber: item.account,
          accountName: account?.name || 'Unknown Account',
          debit: item.debit,
          credit: item.credit,
          description: item.description
        };
      });
      
      const totalAmount = sample.lineItems.reduce((sum, item) => sum + item.debit, 0);
      
      // Create entry
      const entryData = {
        entryNumber,
        reference,
        entryDate: admin.firestore.Timestamp.fromDate(sample.date),
        description: sample.description,
        status: 'posted',
        lineItems,
        totalAmount,
        createdBy: 'SYSTEM',
        createdByName: 'System Administrator',
        postedBy: 'SYSTEM',
        postedByName: 'System Administrator',
        createdAt: admin.firestore.Timestamp.now(),
        postedAt: admin.firestore.Timestamp.fromDate(sample.date),
        updatedAt: admin.firestore.Timestamp.now()
      };
      
      const entryRef = await db.collection('journalEntries').add(entryData);
      
      // Get affected account names
      const affectedAccounts = [...new Set(lineItems.map(item => item.accountName))].join(' | ');
      
      // Create event log for this entry
      await db.collection('eventLogs').add({
        eventId: require('crypto').randomUUID(),
        eventType: 'journal_entry',
        description: `Posted journal entry #${entryNumber}`,
        accountName: affectedAccounts,
        beforeImage: null,
        afterImage: {
          entryNumber,
          reference,
          status: 'posted',
          description: sample.description,
          totalAmount,
          lineItemCount: lineItems.length,
          hasAttachments: false,
          affectedAccounts: affectedAccounts
        },
        userId: 'SYSTEM',
        username: 'System Administrator',
        timestamp: admin.firestore.Timestamp.fromDate(sample.date),
        dateTime: sample.date.toISOString()
      });
      
      // Post to ledger
      for (const item of lineItems) {
        if (!item.accountId) continue;
        
        const ledgerData = {
          accountId: item.accountId,
          accountNumber: item.accountNumber,
          accountName: item.accountName,
          date: admin.firestore.Timestamp.fromDate(sample.date),
          description: sample.description,
          reference,
          journalEntryId: entryRef.id,
          debit: item.debit,
          credit: item.credit,
          createdAt: admin.firestore.Timestamp.fromDate(sample.date)
        };
        
        await db.collection('ledgerTransactions').add(ledgerData);
        
        // Update account balance
        const accountRef = db.collection('accounts').doc(item.accountId);
        const accountDoc = await accountRef.get();
        const accountData = accountDoc.data();
        const currentBalance = accountData.balance || 0;
        const newBalance = currentBalance + item.debit - item.credit;
        
        await accountRef.update({
          balance: newBalance,
          updatedAt: admin.firestore.Timestamp.now()
        });
      }
      
      createdEntries.push({
        entryNumber,
        reference,
        description: sample.description
      });
    }
    
    res.json({ 
      success: true,
      message: 'Cleanup and seeding completed successfully',
      deleted: {
        journalEntries: testEntryIds.length,
        entryNumbers: testEntryNumbers
      },
      created: createdEntries
    });
    
  } catch (error) {
    console.error('Error in cleanup and seed:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

// Delete event logs with missing event IDs
app.post('/cleanup-invalid-event-logs', async (req, res) => {
  try {
    const db = admin.firestore();
    const batch = db.batch();
    
    // Find all event logs without eventId or with eventId = null
    const eventLogsSnapshot = await db.collection('eventLogs').get();
    let deletedCount = 0;
    
    eventLogsSnapshot.forEach(doc => {
      const data = doc.data();
      // Delete if eventId is missing, null, or undefined
      if (!data.eventId) {
        batch.delete(doc.ref);
        deletedCount++;
      }
    });
    
    // Commit deletions
    await batch.commit();
    console.log(`Deleted ${deletedCount} event logs with missing event IDs`);
    
    res.json({ 
      success: true,
      message: 'Invalid event logs cleaned up successfully',
      deleted: deletedCount
    });
    
  } catch (error) {
    console.error('Error cleaning up invalid event logs:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

// Update sample entries to use specific username
app.post('/update-sample-entries-user', async (req, res) => {
  try {
    const db = admin.firestore();
    
    // Update journal entries created by SYSTEM to pingram0323
    const journalEntriesSnapshot = await db.collection('journalEntries')
      .where('createdBy', '==', 'SYSTEM')
      .get();
    
    const batch = db.batch();
    journalEntriesSnapshot.forEach(doc => {
      batch.update(doc.ref, {
        createdBy: 'pingram0323',
        createdByName: 'pingram0323',
        postedBy: 'pingram0323',
        postedByName: 'pingram0323'
      });
    });
    
    // Update event logs
    const eventLogsSnapshot = await db.collection('eventLogs')
      .where('userId', '==', 'SYSTEM')
      .get();
    
    eventLogsSnapshot.forEach(doc => {
      batch.update(doc.ref, {
        userId: 'pingram0323',
        username: 'pingram0323'
      });
    });
    
    await batch.commit();
    
    res.json({ 
      success: true,
      message: 'Sample entries updated successfully',
      updated: {
        journalEntries: journalEntriesSnapshot.size,
        eventLogs: eventLogsSnapshot.size
      }
    });
    
  } catch (error) {
    console.error('Error updating sample entries:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

// Update event logs to include affected accounts
app.post('/update-event-logs-accounts', async (req, res) => {
  try {
    const db = admin.firestore();
    
    // Get all journal entries
    const journalEntriesSnapshot = await db.collection('journalEntries').get();
    const entriesMap = {};
    
    journalEntriesSnapshot.forEach(doc => {
      const data = doc.data();
      if (data.lineItems && data.lineItems.length > 0) {
        const affectedAccounts = [...new Set(data.lineItems.map(item => item.accountName))].join(' | ');
        entriesMap[data.entryNumber] = affectedAccounts;
      }
    });
    
    // Update event logs for journal entries
    const eventLogsSnapshot = await db.collection('eventLogs')
      .where('eventType', '>=', 'journal_entry')
      .where('eventType', '<=', 'journal_entry_rejected')
      .get();
    
    const batch = db.batch();
    let updatedCount = 0;
    
    eventLogsSnapshot.forEach(doc => {
      const data = doc.data();
      const accountName = data.accountName || '';
      
      // Extract entry number from accountName like "Journal Entry #3"
      const match = accountName.match(/Journal Entry #(\d+)/);
      if (match) {
        const entryNumber = parseInt(match[1]);
        const affectedAccounts = entriesMap[entryNumber];
        
        if (affectedAccounts) {
          batch.update(doc.ref, {
            accountName: affectedAccounts,
            'afterImage.affectedAccounts': affectedAccounts
          });
          updatedCount++;
        }
      }
    });
    
    await batch.commit();
    
    res.json({ 
      success: true,
      message: 'Event logs updated with affected accounts',
      updated: updatedCount
    });
    
  } catch (error) {
    console.error('Error updating event logs:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

// Fix existing event logs to use pipe separator
app.post('/fix-event-logs-separator', async (req, res) => {
  try {
    const db = admin.firestore();
    
    // Get all event logs for journal entries
    const eventLogsSnapshot = await db.collection('eventLogs')
      .where('eventType', 'in', ['journal_entry', 'journal_entry_approved', 'journal_entry_rejected', 'journal_entry_posted'])
      .get();
    
    const batch = db.batch();
    let updatedCount = 0;
    
    eventLogsSnapshot.forEach(doc => {
      const data = doc.data();
      const accountName = data.accountName || '';
      
      // If accountName contains comma, replace with pipe
      if (accountName.includes(',')) {
        const fixed = accountName.replace(/,\s*/g, ' | ');
        batch.update(doc.ref, {
          accountName: fixed
        });
        
        // Also update afterImage if it exists
        if (data.afterImage?.affectedAccounts && data.afterImage.affectedAccounts.includes(',')) {
          batch.update(doc.ref, {
            'afterImage.affectedAccounts': data.afterImage.affectedAccounts.replace(/,\s*/g, ' | ')
          });
        }
        updatedCount++;
      }
    });
    
    await batch.commit();
    
    res.json({ 
      success: true,
      message: 'Event logs separators fixed',
      updated: updatedCount
    });
    
  } catch (error) {
    console.error('Error fixing event log separators:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    service: 'Firebase Admin Server',
    timestamp: new Date().toISOString()
  });
});

// Cleanup endpoint - Delete pending approval entries
app.post('/cleanup-pending-approvals', async (req, res) => {
  try {
    const db = admin.firestore();
    
    console.log('🔍 Searching for pending approval entries...');
    
    const snapshot = await db.collection('journalEntries')
      .where('status', '==', 'pending_approval')
      .get();
    
    console.log(`Found ${snapshot.size} pending approval entries`);
    
    if (snapshot.size === 0) {
      return res.json({ 
        success: true, 
        message: 'No pending approval entries to delete',
        deleted: 0
      });
    }
    
    const batch = db.batch();
    const deletedEntries = [];
    
    snapshot.forEach(doc => {
      const data = doc.data();
      deletedEntries.push({
        id: doc.id,
        entryNumber: data.entryNumber,
        description: data.description
      });
      batch.delete(doc.ref);
    });
    
    await batch.commit();
    
    console.log('✅ Deleted pending approval entries:');
    deletedEntries.forEach(entry => {
      console.log(`   - Entry #${entry.entryNumber}: ${entry.description}`);
    });
    
    res.json({ 
      success: true, 
      message: `Deleted ${deletedEntries.length} pending approval entries`,
      deleted: deletedEntries.length,
      entries: deletedEntries
    });
    
  } catch (error) {
    console.error('❌ Error cleaning up entries:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Firebase Admin Server running on http://0.0.0.0:${PORT}`);
  console.log(`Health check: http://0.0.0.0:${PORT}/health`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Firebase Admin Server shutting down...');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('Firebase Admin Server shutting down...');
  process.exit(0);
});