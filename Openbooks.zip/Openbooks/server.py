#!/usr/bin/env python3
"""
Simple HTTP server to serve the OpenBooks static web application.
Serves files from the web/ directory on port 5000.
"""
import http.server
import socketserver
import os
import sys
import json
import urllib.request
import urllib.parse
import urllib.error

# Change to the web directory to serve static files
os.chdir('web')

PORT = 5000
HOST = '0.0.0.0'
FIREBASE_ADMIN_PORT = 3001

# Get Firebase Admin URL from environment or default to localhost
FIREBASE_ADMIN_URL = os.environ.get('FIREBASE_ADMIN_URL', f'http://localhost:{FIREBASE_ADMIN_PORT}')

class MyHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        # Add cache control headers to prevent caching issues in Replit
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        super().end_headers()

    def log_message(self, format, *args):
        # Custom logging format
        print(f"[{self.address_string()}] {format % args}")

    def do_GET(self):
        # Handle API endpoints
        if self.path == '/api/get-repl-token':
            self.handle_get_repl_token()
        else:
            # Continue with normal file serving
            super().do_GET()

    def do_POST(self):
        # Handle Firebase Admin API proxy for production
        if self.path == '/api/delete-firebase-user':
            self.proxy_firebase_admin_request('delete-firebase-user')
        elif self.path == '/api/create-firebase-user':
            self.proxy_firebase_admin_request('create-firebase-user')
        elif self.path == '/api/update-firebase-user':
            self.proxy_firebase_admin_request('update-firebase-user')
        elif self.path == '/api/send-email':
            self.handle_send_email()
        else:
            self.send_error(404, "Endpoint not found")

    def handle_send_email(self):
        """Send email using Replit Mail service with proper server-side authentication"""
        try:
            # Read the request body
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            email_data = json.loads(post_data.decode('utf-8'))
            
            # Get the proper Replit token
            repl_identity = os.environ.get('REPL_IDENTITY')
            web_repl_renewal = os.environ.get('WEB_REPL_RENEWAL')
            
            auth_token = None
            if repl_identity:
                auth_token = f"repl {repl_identity}"
            elif web_repl_renewal:
                auth_token = f"depl {web_repl_renewal}"
            
            if not auth_token:
                self.send_response(400)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                error_data = {'error': 'No Replit authentication token available'}
                self.wfile.write(json.dumps(error_data).encode())
                return
            
            # Prepare the email data for Replit Mail service
            mail_data = {
                'to': email_data.get('to'),
                'subject': email_data.get('subject'),
                'text': email_data.get('text')
            }
            
            # Optional fields
            if email_data.get('cc'):
                mail_data['cc'] = email_data.get('cc')
            if email_data.get('html'):
                mail_data['html'] = email_data.get('html')
            if email_data.get('attachments'):
                mail_data['attachments'] = email_data.get('attachments')
            
            # Send request to Replit Mail service
            req = urllib.request.Request(
                "https://connectors.replit.com/api/v2/mailer/send",
                data=json.dumps(mail_data).encode('utf-8'),
                headers={
                    'Content-Type': 'application/json',
                    'X_REPLIT_TOKEN': auth_token
                },
                method='POST'
            )
            
            with urllib.request.urlopen(req) as response:
                response_data = response.read()
                result = json.loads(response_data.decode('utf-8'))
                
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(result).encode())
                
        except urllib.error.HTTPError as e:
            print(f"Replit Mail API error: {e.code} - {e.reason}")
            try:
                error_response = e.read().decode('utf-8')
                error_data = json.loads(error_response)
            except:
                error_data = {'error': f'HTTP {e.code}: {e.reason}'}
            
            self.send_response(e.code)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(error_data).encode())
            
        except Exception as e:
            print(f"Error sending email: {e}")
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            error_data = {'error': 'Internal server error'}
            self.wfile.write(json.dumps(error_data).encode())

    def handle_get_repl_token(self):
        """Get Replit authentication token for email service"""
        try:
            # Get the proper Replit token from environment variables
            repl_identity = os.environ.get('REPL_IDENTITY')
            web_repl_renewal = os.environ.get('WEB_REPL_RENEWAL')
            
            token = None
            if repl_identity:
                token = f"repl {repl_identity}"
            elif web_repl_renewal:
                token = f"depl {web_repl_renewal}"
            
            if token:
                response_data = {'token': token}
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(response_data).encode())
            else:
                self.send_response(404)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                error_data = {'error': 'No Replit authentication token found'}
                self.wfile.write(json.dumps(error_data).encode())
                
        except Exception as e:
            print(f"Error getting Replit token: {e}")
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            error_data = {'error': 'Internal server error'}
            self.wfile.write(json.dumps(error_data).encode())

    def proxy_firebase_admin_request(self, endpoint):
        try:
            # Read the request body
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            
            # Forward to Firebase Admin server using configurable URL
            firebase_admin_url = f"{FIREBASE_ADMIN_URL}/{endpoint}"
            
            req = urllib.request.Request(
                firebase_admin_url,
                data=post_data,
                headers={'Content-Type': 'application/json'}
            )
            
            with urllib.request.urlopen(req) as response:
                response_data = response.read()
                
                # Send successful response
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
                self.send_header('Access-Control-Allow-Headers', 'Content-Type')
                self.end_headers()
                self.wfile.write(response_data)
                
        except Exception as e:
            # Handle errors
            error_response = {
                "success": False,
                "error": f"Proxy error: {str(e)}",
                "warning": "Firebase Auth account may still exist"
            }
            
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps(error_response).encode())

    def do_OPTIONS(self):
        # Handle CORS preflight
        if self.path in ['/api/delete-firebase-user', '/api/create-firebase-user']:
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
            self.send_header('Access-Control-Allow-Headers', 'Content-Type')
            self.end_headers()
        else:
            # Default OPTIONS handling
            self.send_response(405)
            self.end_headers()

if __name__ == "__main__":
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer((HOST, PORT), MyHTTPRequestHandler) as httpd:
        print(f"Server started at http://{HOST}:{PORT}")
        print(f"Serving files from: {os.getcwd()}")
        print(f"Firebase Admin URL: {FIREBASE_ADMIN_URL}")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServer stopped.")
            sys.exit(0)