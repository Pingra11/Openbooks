# OpenBooks - Accounting & User Management System
---

## Quick Start

### Windows

Double-click `start-openbooks.bat` to launch OpenBooks. Your browser will open automatically.

### Mac/Linux

Run the following in terminal:

```bash
./start-openbooks.sh
```

Then open your browser and enter: `http://localhost:5000`

---

## Requirements

Make sure you have these before starting Openbooks

1. **Node.js** (v18 or higher)
   - Download from [nodejs.org](https://nodejs.org)
   
2. **Python 3** (v3.8 or higher)
   - Download from [python.org](https://python.org)

3. **Install Dependencies** (first time only)

   ```bash
   npm install
   ```

---

## Project Structure

```
OpenBooks/
├── web/                      # Frontend files (HTML, CSS, JavaScript)
│   ├── css/                  # Stylesheets
│   ├── js/                   # JavaScript modules
│   ├── assets/               # Images and icons
│   └── *.html                # HTML pages
├── firebase-admin-server.js  # Node.js admin API server
├── firebase-service-account.json  # Firebase credentials
├── server.py                 # Python web server with API proxy
├── package.json              # Node.js dependencies

```

---

## User Roles

| Role | Permissions |
|------|-------------|
| **Administrator** | Full access: user management, all accounting features, system settings |
| **Manager** | Approve/reject journal entries, view reports, manage accounts |
| **Accountant** | Create journal entries (requires approval), view ledgers and reports |


---

## Configuration

### Firebase Setup
OpenBooks uses Firebase for authentication and database. The `firebase-service-account.json` file contains your Firebase credentials.


---

## Ports Used

| Port | Service |
|------|---------|
| 5000 | Main web server (access OpenBooks here) |
| 3001 | Firebase Admin API server (internal) |


---

## Stopping OpenBooks

- **Windows:** Press any key in the launcher window
- **Mac/Linux:** Press Ctrl+C in the terminal
- **Manual:** Close both terminal windows running the servers

---
